package fiuba.algo3.modelo.excepciones;

public class NoSePuedeCalcularLaDistanciaException extends RuntimeException {

}