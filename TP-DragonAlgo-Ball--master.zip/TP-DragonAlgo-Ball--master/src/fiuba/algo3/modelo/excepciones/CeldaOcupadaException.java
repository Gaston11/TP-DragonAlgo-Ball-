package fiuba.algo3.modelo.excepciones;

public class CeldaOcupadaException extends RuntimeException {

	// Excepcion a lanzar cuando una celda ya esta ocupada
}
