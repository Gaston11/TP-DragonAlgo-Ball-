package fiuba.algo3.modelo.excepciones;

public class NoSePuedeAbsorberPersonajeException extends RuntimeException{

}