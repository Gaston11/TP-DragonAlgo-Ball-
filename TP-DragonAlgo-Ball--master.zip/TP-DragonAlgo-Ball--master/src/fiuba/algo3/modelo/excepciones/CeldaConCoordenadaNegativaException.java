package fiuba.algo3.modelo.excepciones;

/**
 * Created by gaston on 29/06/17.
 */
public class CeldaConCoordenadaNegativaException extends RuntimeException {
    // Celda con coordenada negativa
}
