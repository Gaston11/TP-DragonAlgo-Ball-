package fiuba.algo3.modelo.excepciones;

public class NoSePuedeTransformarPersonajeException extends RuntimeException{

}