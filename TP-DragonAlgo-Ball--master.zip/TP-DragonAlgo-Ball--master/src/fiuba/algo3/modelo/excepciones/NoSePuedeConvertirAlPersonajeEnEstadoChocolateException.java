package fiuba.algo3.modelo.excepciones;

public class NoSePuedeConvertirAlPersonajeEnEstadoChocolateException extends RuntimeException {

}