package fiuba.algo3.modelo.excepciones;

/**
 * Created by noe on 01/07/17.
 */
public class PersonajeInvalidoException extends RuntimeException {
}
