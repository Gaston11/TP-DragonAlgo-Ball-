package fiuba.algo3.modelo.excepciones;

public class NoSePuedeMoverPersonajeException extends RuntimeException {


}