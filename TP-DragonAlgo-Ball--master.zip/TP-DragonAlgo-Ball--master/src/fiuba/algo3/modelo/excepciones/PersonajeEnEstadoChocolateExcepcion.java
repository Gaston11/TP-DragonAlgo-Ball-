package fiuba.algo3.modelo.excepciones;

public class PersonajeEnEstadoChocolateExcepcion extends RuntimeException{

}