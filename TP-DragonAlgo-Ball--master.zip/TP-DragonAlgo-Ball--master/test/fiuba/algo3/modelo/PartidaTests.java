package fiuba.algo3.modelo;

//import fiuba.algo3.modelo.Juego.Partida;
import org.junit.Test;

public class PartidaTests {
/*
    //Por ahora sólo prueban que no explota al ejecutar los métodos
    @Test
    public void crearNuevaPartida() {
        Partida partida = new Partida("Jorge", "Alejandra");
    }

    @Test
    public void cambiarTurnoDeJugador(){
        Partida partida = new Partida("Pedro","Pablo");
        partida.finTurno();
    }*/
}
